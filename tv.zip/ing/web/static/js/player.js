	let currentWs = null;
	let mseQueue = [],
	    mseSourceBuffer, mseStreamingStarted = false, videoSound=false;

	let currentVideoUuid = '1';
	let isLoading = false;
	  
	  $(document).ready(() => {
	    startPlay();
	 });
	  
	  function showVideo(uuid) {
	    console.log('UUID:', uuid);
	    if (currentVideoUuid !== uuid !== 7) {
		const video = document.getElementById('videoPlayer');
		currentVideoUuid = uuid;
		mseQueue = [];
		if (currentWs) {
		    currentWs.close();
		}
		isLoading = true; // Set isLoading flag when starting to load a new video
		startPlay(uuid);
	    }
	}
	
	  function startPlay(uuid=null) {
	    uuid = uuid || '1';
	    channel = 0;
	    
	    let protocol = location.protocol == 'https:' ? 'wss' : 'ws';
	    let url = protocol + '://' + location.host + '/stream/' + uuid + '/channel/' + channel + '/mse?uuid=' + uuid + '&channel=' + channel;
	    let mse = new MediaSource();
	    $("#videoPlayer")[0].src = window.URL.createObjectURL(mse);
	    mse.addEventListener('sourceopen', function() {
		if (currentWs) {
		    currentWs.close();
		}
		let ws = new WebSocket(url);
		ws.binaryType = "arraybuffer";
		ws.onopen = function(event) {
		    console.log('Connect to ws');
		    isLoading = false; // Reset isLoading flag when video is loaded
		}
		ws.onmessage = function(event) {
		    let data = new Uint8Array(event.data);
		    if (data[0] == 9) {
		        decoded_arr = data.slice(1);
		        if (window.TextDecoder) {
		            mimeCodec = new TextDecoder("utf-8").decode(decoded_arr);
		        } else {
		            mimeCodec = Utf8ArrayToStr(decoded_arr);
		        }
		        if(mimeCodec.indexOf(',')>0){
		            videoSound=true;
		        }
		        mseSourceBuffer = mse.addSourceBuffer('video/mp4; codecs="' + mimeCodec + '"');
		        mseSourceBuffer.mode = "segments"
		        mseSourceBuffer.addEventListener("updateend", pushPacket);

		    } else {
		        readPacket(event.data);
		    }
		};
		currentWs = ws;
	    }, false);

	    isLoading = true; // Set isLoading flag when starting to load a new video
	}
	  
	  function pushPacket() {
	    if (!mseSourceBuffer.updating && !isLoading) { // Check isLoading flag
		if (mseQueue.length > 0) {
		    packet = mseQueue.shift();
		    mseSourceBuffer.appendBuffer(packet);
		} else {
		    mseStreamingStarted = false;
		}
	    }
	    if ($("#videoPlayer")[0].buffered.length > 0) {
		if (typeof document.hidden !== "undefined" && document.hidden && !videoSound) {
		    $("#videoPlayer")[0].currentTime = $("#videoPlayer")[0].buffered.end(($("#videoPlayer")[0].buffered.length - 1)) - 0.5;
		}
	    }
	}

	  function readPacket(packet) {
	    if (!mseStreamingStarted && !isLoading) { // Check isLoading flag
		mseSourceBuffer.appendBuffer(packet);
		mseStreamingStarted = true;
		return;
	    }
	    mseQueue.push(packet);
	    if (!mseSourceBuffer.updating && !isLoading) { // Check isLoading flag
		pushPacket();
	    }
	}

//Play
	  $("#videoPlayer")[0].addEventListener('loadeddata', () => {
	    $("#videoPlayer")[0].play();
	  });

	  $("#videoPlayer")[0].addEventListener('error', () => {
	    console.log('video_error')
	  });
	  
	function toggleFullscreen() {
    const video = document.getElementById('videoPlayer');
    if (document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement) {
        // Exit fullscreen
        if (document.exitFullscreen) {
            document.exitFullscreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }
    } else {
        // Enter fullscreen
        if (video.requestFullscreen) {
            video.requestFullscreen();
        } else if (video.msRequestFullscreen) {
            video.msRequestFullscreen();
        } else if (video.mozRequestFullScreen) {
            video.mozRequestFullScreen();
        } else if (video.webkitRequestFullscreen) {
            video.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
        }
    }
}



	 
	


	let selectedIconIndex = 1;
	let totalIcons = $('.card-outline').length;


	function displayKey(key) {
	    console.log('Key pressed:', key);
	}

document.addEventListener('contextmenu', function(event) {
    event.preventDefault(); // Prevent the default context menu
});

$(document).keyup(function (e) {
    displayKey(e.keycode);

    if (e.key === 'ArrowRight') {
        if (selectedIconIndex < totalIcons) {
            selectedIconIndex++;
            selectIcon(selectedIconIndex);
        }
    }

    if (e.key === 'ArrowLeft') {
        if (selectedIconIndex > 1) {
            selectedIconIndex--;
            selectIcon(selectedIconIndex);
        }
    }

    if (e.key === 'ArrowUp') {
        if (selectedIconIndex >= 5) {
            selectedIconIndex -= 4;
            selectIcon(selectedIconIndex);
        }
    }


    if (e.key === 'ArrowDown') {

        if (selectedIconIndex <= totalIcons - 4) {
            selectedIconIndex += 4;
            selectIcon(selectedIconIndex);
        }
    }

    if (e.key === 'Enter') {
    if (selectedIconIndex !== 7) {
        toggleFullscreen();
    } else {
        window.location.href = 'https://www.netflix.com/my-en/login';
    }
}

    

});


function selectIcon(index) {
    $('.card-outline').removeClass('selected');
    $(`#content${index} .card-outline`).addClass('selected');
    $('.card-outline').removeClass('hovered');
    $(`#content${index} .card-outline`).addClass('hovered');
    $('.card-outline').css('border', 'none');
    $(`#content${index} .card-outline`).css('border', '2px solid blue');

    const uuid = $(`#content${index}`).data('name');
    showVideo(uuid);
}

selectIcon(selectedIconIndex);



